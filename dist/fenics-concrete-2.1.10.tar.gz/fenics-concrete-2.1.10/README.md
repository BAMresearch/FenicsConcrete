# FenicsConcrete
FE model representing the hardening of concrete

more details will be added
